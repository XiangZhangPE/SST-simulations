% ------------------------------------------------------------------------
% Technical note TN165
% Simulink model of a 3-phase star-connected cascaded H-bridge converter
% Copyright : Imperix Switzerland ltd 2024
% Engineers : Jonathan Orsinger
% ------------------------------------------------------------------------
clc; close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%   Timing parameters     %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
f_clk0 = 20e3;              % [Hz], interrupt and switching frequency
Ts = 1/f_clk0;              % [s], interrupt and switching period

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%   Topology parameters   %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N_perPhase     = 4;    		% number of stages per phase
N_phase        = 3;	 		% number of phases (1 or 3[star])

%Phase mapping
phase_mapping  = repelem(1:N_phase, N_perPhase); % phase mapping for each stage

% Derived parameters
N = N_perPhase*N_phase; % total number of stages

% Installed stages (in model)
N_installed = 24;
if N > N_installed
    error(['The total number of stages must not exceed N_installed = ' num2str(N_installed)]);
end

% Matrix for averaging dc-link voltages in each phase
M_Vdc_mean = ones(1,N_perPhase)/N_perPhase;
if N_phase == 3
	M_Vdc_mean = blkdiag(M_Vdc_mean, M_Vdc_mean, M_Vdc_mean);
end

% Variants for vector probes and plant
variant_st0_Active   = Simulink.Variant('N_perPhase >  0');
variant_st0_Inactive = Simulink.Variant('N_perPhase <= 0');
variant_st1_Active   = Simulink.Variant('N_perPhase >  1');
variant_st1_Inactive = Simulink.Variant('N_perPhase <= 1');
variant_st2_Active   = Simulink.Variant('N_perPhase >  2');
variant_st2_Inactive = Simulink.Variant('N_perPhase <= 2');
variant_st3_Active   = Simulink.Variant('N_perPhase >  3');
variant_st3_Inactive = Simulink.Variant('N_perPhase <= 3');
variant_st4_Active   = Simulink.Variant('N_perPhase >  4');
variant_st4_Inactive = Simulink.Variant('N_perPhase <= 4');
variant_st5_Active   = Simulink.Variant('N_perPhase >  5');
variant_st5_Inactive = Simulink.Variant('N_perPhase <= 5');
variant_st6_Active   = Simulink.Variant('N_perPhase >  6');
variant_st6_Inactive = Simulink.Variant('N_perPhase <= 6');
variant_st7_Active   = Simulink.Variant('N_perPhase >  7');
variant_st7_Inactive = Simulink.Variant('N_perPhase <= 7');

% Carrier phase shifts for CHB
phaseShift_BB0 = repelem(linspace(0,(1-1/N_perPhase)/2, N_perPhase), 2);         % phase A
phaseShift_BB1 = repelem(linspace(0,(1-1/N_perPhase)/2, N_perPhase) + 1/N/2, 2); % phase B
phaseShift_BB2 = repelem(linspace(0,(1-1/N_perPhase)/2, N_perPhase) +2 /N/2, 2); % phase C

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%    Power  parameters    %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Grid voltage
Vac_rms_LL = 400; %Vrms line-to-line
% Grid frequency
f_grid = 50;
% Grid inductors
Lb = 2.5e-3;
Rb = 22e-3;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%   Control parameters    %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Setpoints
boostFactor = 1.4; % boost factor between rectified grid voltage (peak) and Vdc
Vdc_ref     = ceil(Vac_rms_LL*sqrt(2)/N_perPhase/2*boostFactor/10)*10; % DC capacitor voltage reference

% Grid current control (magnitude optimum)
Tdtot = 1/f_clk0; % total control delay
Tn = Lb/Rb;
Ti = 2/Rb*Tdtot;
Kp_ig = Tn/Ti;
Ki_ig = 1/Ti;

Ig_ref_max = 20; %A, saturation limit and anti-windup

% Average DC-link voltage control
Cdc_st = 5e-3;                % DC-link capacitance of one stage
Cdc_eq = 3/4*Cdc_st/N_perPhase;   % DC-link capacitance of equivalent non-cascaded inverter

wBW_Vdc = 0.8*pi*f_grid;    % [rad/s] bandwidth of controller
PM_Vdc  = 50;               % [deg] phase margin of controller

a_Vdc = tan(PM_Vdc/180*pi);
Kp_Vdc = wBW_Vdc*2/3*sqrt(3)*boostFactor*Cdc_eq/sqrt(1+1/a_Vdc^2);
Ki_Vdc = Kp_Vdc*wBW_Vdc/a_Vdc;

% Pre-charge state machine, safety checks
f_min 	 = f_grid*0.96;  % [Hz]
f_max 	 = f_grid*1.04;  % [Hz]
Vgrid_min = 100;         % [V peak]
Vdc_max   = 200;         % [V dc]

% Deadtime and compensation parameters
DT   = 1e-6;             % [s], dead-time for complementarty PWM signals
Vf   = [0 0.9 2.1 2.4];	 % [V], forward voltage drop of IGBTs and diodes (lookup table)
I_Vf = [0 0.1 10 30];    % [A], current vector for Vf lookup table

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Simulation parameters  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initial voltages (unbalanced)
Vdc0 = Vdc_ref*(repelem(linspace(-0.04,0.04,N_installed/N_phase),N_phase)+repmat(linspace(0.9,1.1,N_phase),1,N_installed/N_phase));

% Simulation mode (bypass the state machine)
isSim = 1; % ignored in code generation